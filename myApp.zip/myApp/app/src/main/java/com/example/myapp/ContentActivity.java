package com.example.myapp;

import static androidx.core.content.ContextCompat.startActivity;
import com.example.myapp.databinding.ActivityMainBinding;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class ContentActivity extends Activity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
        setContentView(R.layout.content_main);

        DBSetter dbinv = new DBSetter(ContentActivity.this);

        EditText inventoryDescEdt = findViewById(R.id.idInventoryDescriptionInput);
        EditText inventoryNameEdt = findViewById(R.id.idInventoryNameInput);
        EditText inventoryQuantityEdt = findViewById(R.id.idInventoryQuantityInput);
        Button addInventoryBtn = findViewById(R.id.addInventory);
        Button readInventoryBtn = findViewById(R.id.readInventoryBtn);


        addInventoryBtn.setOnClickListener(view -> {
        String inventoryName = inventoryNameEdt.getText().toString();
        String inventoryDesc = inventoryDescEdt.getText().toString();
        String inventoryQuantity = inventoryQuantityEdt.getText().toString();

        // validating if the text fields are empty or not.
        if (inventoryName.isEmpty() || inventoryDesc.isEmpty() || inventoryQuantity.isEmpty()) {
            Toast.makeText(ContentActivity.this, "Please enter all the data..", Toast.LENGTH_LONG).show();
            return;
        }

        // on below line we are calling a method to add new
        // inventory to sqlite data and pass all our values to it.
            dbinv.addNewInventory(inventoryName, inventoryQuantity, inventoryDesc);

        // after adding the data we are displaying a toast message.
        Toast.makeText(ContentActivity.this, "inventory has been added.", Toast.LENGTH_LONG).show();
        inventoryNameEdt.setText("");
        inventoryDescEdt.setText("");
        inventoryQuantityEdt.setText("");
        });
        readInventoryBtn.setOnClickListener(v -> {
            // opening a new activity via a intent.
            Intent i = new Intent(getApplicationContext(), ViewInventory.class);
            startActivity(i);
        });
    }
}

