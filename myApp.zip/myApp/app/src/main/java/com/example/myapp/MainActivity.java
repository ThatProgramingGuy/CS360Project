package com.example.myapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.ui.AppBarConfiguration;

import com.example.myapp.databinding.ActivityMainBinding;
import com.google.android.material.snackbar.Snackbar;

public class MainActivity extends AppCompatActivity {

    private AppBarConfiguration appBarConfiguration;
    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.toolbar);

        EditText userNameInput = (EditText) findViewById(R.id.userName);
        EditText passwordInput = (EditText) findViewById(R.id.password);

        DBSetter dbSetter = new DBSetter(MainActivity.this);

        binding.LoginButton.setOnClickListener(view -> {
            String USERNAME = (userNameInput.getText()).toString();
            String PASSWORD = (passwordInput.getText()).toString();
            boolean recordExists = dbSetter.queryLogin(USERNAME, PASSWORD);

            if (USERNAME.isEmpty() || PASSWORD.isEmpty()) {
                Snackbar.make(view, "Please input all fields of input.", Snackbar.LENGTH_LONG)
                        .setAnchorView(R.id.LoginButton);
            }
                    if (recordExists) {
                        Intent intentSignIn = new Intent(getApplicationContext(), ContentActivity.class);
                        Toast.makeText(getApplicationContext(), "Login successful.", Toast.LENGTH_LONG).show();
                        startActivity(intentSignIn);
                    } else {
                        dbSetter.addNewLogin(USERNAME, PASSWORD);
                        Toast.makeText(getApplicationContext(), "Creating new login with username " + USERNAME, Toast.LENGTH_LONG).show();
                    }

        });

}}