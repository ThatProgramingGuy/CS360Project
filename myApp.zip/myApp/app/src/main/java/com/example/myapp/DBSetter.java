package com.example.myapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.AbstractCursor;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class DBSetter extends SQLiteOpenHelper {

    // creating a constant variables for our database.
    // below variable is for our database name.
    private static final String DB_NAME = "Inventorydb";

    // below int is our database version
    private static final int DB_VERSION = 1;

    // below variable is for our table name.
    private static final String TABLE_NAME = "loginTable";
    private static final String TABLE_NAME2 = "inventoryTable";

    // below variable is for our id column.
    private static final String ID_COL = "id";

    // below variable is for our Inventory name column
    private static final String USERNAME_COL = "username";
    private static final String NAME_COL = "name";
    private static final String QUANTITY_COL = "quantity";
    private static final String DESCRIPTION_COL = "description";
    private static final String PASSWORD_COL = "password";
    public DBSetter(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    // below method is for creating a database by running a sqlite query
    @Override
    public void onCreate(SQLiteDatabase dbinv){
        SQLiteDatabase db = dbinv;
        // on below line we are creating
        // an sqlite query and we are
        // setting our column names
        // along with their data types.
        String query = "CREATE TABLE " + TABLE_NAME + " ("
                + ID_COL + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + USERNAME_COL + " TEXT,"
                + PASSWORD_COL + " TEXT)";

        String query2 = "CREATE TABLE " + TABLE_NAME2 + " ("
                + NAME_COL + " TEXT,"
                + QUANTITY_COL + " TEXT,"
                + DESCRIPTION_COL + " TEXT)";
        //dbinv = conCreate(dbinv);

        // at last we are calling a exec sql
        // method to execute above sql query
        db.execSQL(query2);
        db.execSQL(query);
    }

    public void addNewInventory(String inventoryName, String inventoryQuantity, String inventoryDesc) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues contentValues = new ContentValues();

        contentValues.put(NAME_COL, inventoryName);
        contentValues.put(QUANTITY_COL, inventoryQuantity);
        contentValues.put(DESCRIPTION_COL, inventoryDesc);

        db.insert(TABLE_NAME2, null, contentValues);

        db.close();
    }
    public void addNewLogin(String loginUserName, String loginPassword) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(USERNAME_COL, loginUserName);
        values.put(PASSWORD_COL, loginPassword);

        db.insert(TABLE_NAME, null, values);

        db.close();
    }



    public ArrayList<InventoryModal> readInventory() {
        // on below line we are creating a
    // database for reading our database.
    SQLiteDatabase db = this.getReadableDatabase();

    // on below line we are creating a cursor with query to read data from database.
    Cursor cursorInventory = db.rawQuery("SELECT * FROM " + TABLE_NAME2, null);

    // on below line we are creating a new array list.
    ArrayList<InventoryModal> InventoryModalArrayList = new ArrayList<>();
        cursorInventory.moveToFirst();

        if (cursorInventory.moveToFirst()) {
            do {
                // on below line we are adding the data from cursor to our array list.
                InventoryModalArrayList.add(new InventoryModal(cursorInventory.getString(0),
                        cursorInventory.getString(1),
                        cursorInventory.getString(2)));
                cursorInventory.close();
            } while (cursorInventory.moveToNext());
            // moving our cursor to next.
        }
        db.close();
        return InventoryModalArrayList;
}

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // this method is called to check if the table exists already.
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }


    public boolean queryLogin(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        String selectStringU = "SELECT " + USERNAME_COL + " FROM " + TABLE_NAME + " WHERE " + USERNAME_COL + "='" + username + "';";
        String selectStringP = "SELECT " + PASSWORD_COL + " FROM " + TABLE_NAME + " WHERE " + PASSWORD_COL + "='" + password + "';";
        boolean exist = false;

        Cursor cursor = db.rawQuery(selectStringU,null);
        boolean UsernameExist;
        if(cursor.getCount()>0){
            UsernameExist=true;
        } else {
            UsernameExist=false;
        }

        Cursor cursor2 = db.rawQuery(selectStringP,null);
        boolean PasswordExist;
        if(cursor2.getCount()>0){
            PasswordExist=true;
        } else {
            PasswordExist=false;
        }
        db.close();
        cursor.close();

        if(PasswordExist && UsernameExist) {
            exist = true;
        }

        return exist;
    }
}
