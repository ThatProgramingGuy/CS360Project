package com.example.myapp;

public class InventoryModal {

    // variables for our Inventoryname,
    // description, tracks and Quantity, id.
    private String InventoryName;
    private String InventoryQuantity;
    private String InventoryDescription;
    private int id;

    // creating getter and setter methods
    public String getInventoryName() { return InventoryName; }

    public void setInventoryName(String InventoryName)
    {
        this.InventoryName = InventoryName;
    }

    public String getInventoryQuantity()
    {
        return InventoryQuantity;
    }

    public void setInventoryQuantity(String InventoryQuantity)
    {
        this.InventoryQuantity = InventoryQuantity;
    }


    public String getInventoryDescription()
    {
        return InventoryDescription;
    }

    public void
    setInventoryDescription(String InventoryDescription)
    {
        this.InventoryDescription = InventoryDescription;
    }

    public int getId() { return id; }

    public void setId(int id) { this.id = id; }

    // constructor
    public InventoryModal(String InventoryName,
                       String InventoryQuantity,
                       String InventoryDescription)
    {
        this.InventoryName = InventoryName;
        this.InventoryQuantity = InventoryQuantity;
        this.InventoryDescription = InventoryDescription;
    }
}
