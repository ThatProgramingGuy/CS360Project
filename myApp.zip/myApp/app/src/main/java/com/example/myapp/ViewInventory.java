package com.example.myapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class ViewInventory extends AppCompatActivity {

    // creating variables for our array list,
    // dbSetter, adapter and recycler view.
    private ArrayList<InventoryModal> inventoryModalArrayList;
    private DBSetter dbSetter;
    private InventoryRVAdapter inventoryRVAdapter;
    private RecyclerView inventoryRV;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory_view);

        // initializing our all variables.
        inventoryModalArrayList = new ArrayList<>();
        dbSetter = new DBSetter(ViewInventory.this);

        // getting our inventory array
        // list from db Setter class.
        inventoryModalArrayList = dbSetter.readInventory();

        // on below line passing our array list to our adapter class.
        inventoryRVAdapter = new InventoryRVAdapter(inventoryModalArrayList, ViewInventory.this);
        inventoryRV = findViewById(R.id.idRVInventory);

        // setting layout manager for our recycler view.
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(ViewInventory.this, RecyclerView.VERTICAL, false);
        inventoryRV.setLayoutManager(linearLayoutManager);

        // setting our adapter to recycler view.
        inventoryRV.setAdapter(inventoryRVAdapter);

        Button BackButton = findViewById(R.id.button);

        BackButton.setOnClickListener(v -> {
            // opening a new activity via a intent.
            Intent i = new Intent(getApplicationContext(), ContentActivity.class);
            startActivity(i);
        });
    }
}
