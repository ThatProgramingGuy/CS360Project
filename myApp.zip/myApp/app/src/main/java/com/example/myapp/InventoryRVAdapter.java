package com.example.myapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class InventoryRVAdapter extends RecyclerView.Adapter<InventoryRVAdapter.ViewHolder> {

    // variable for our array list and context
    private final ArrayList<InventoryModal> InventoryModalArrayList;
    private final Context context;

    // constructor
    public InventoryRVAdapter(ArrayList<InventoryModal> InventoryModalArrayList, Context context) {
        this.InventoryModalArrayList = InventoryModalArrayList;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // on below line we are inflating our layout
        // file for our recycler view items.
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.inventory_rv_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        // on below line we are setting data 
        // to our views of recycler view item.
        InventoryModal modal = InventoryModalArrayList.get(position);
        holder.InventoryNameTV.setText(modal.getInventoryName());
        holder.InventoryDescTV.setText(modal.getInventoryDescription());
        holder.InventoryQuantityTV.setText(modal.getInventoryQuantity());
    }

    @Override
    public int getItemCount() {
        // returning the size of our array list
        return InventoryModalArrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        // creating variables for our text views.
        private final TextView InventoryNameTV;
        private final TextView InventoryDescTV;
        private final TextView InventoryQuantityTV;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            // initializing our text views
            InventoryNameTV = itemView.findViewById(R.id.idTVInventoryName);
            InventoryDescTV = itemView.findViewById(R.id.idTVInventoryDescription);
            InventoryQuantityTV = itemView.findViewById(R.id.idTVInventoryQuantity);
        }
    }
}
